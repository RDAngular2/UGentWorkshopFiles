import {Component} from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'application',
    templateUrl: 'application.component.html'
})
export class ApplicationComponent  {

   name : string = "Angular 2 Workshop";


}