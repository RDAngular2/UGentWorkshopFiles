import {Component, OnInit} from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'inbox-screen',
    templateUrl: 'inbox-screen.component.html'
})
export class InboxScreenComponent implements OnInit {

    constructor() { }

    ngOnInit() { }

}