export class Person {

    name : string;

}