import {Component, OnInit, ViewChild} from '@angular/core';
import {Contact} from "../../../model/contact";

@Component({
    moduleId: module.id,
    selector: 'contact-screen-with-routing',
    templateUrl: 'contact-screen-with-routing.component.html'
})
export class ContactScreenWithRoutingComponent {

    constructor() { }


}